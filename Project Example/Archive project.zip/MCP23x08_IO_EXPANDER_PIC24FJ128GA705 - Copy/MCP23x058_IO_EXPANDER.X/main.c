/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.1
        Device            :  PIC24FJ128GA705
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.70
        MPLAB 	          :  MPLAB X v5.50
 */

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

/**
  Section: Included Files
 */
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcp23x08_driver_basic.h"
#include "utilies_file.h"
#include "mcc_generated_files/i2c1.h"

/*
                         Main application
 */

mcp23x08_info_t mcp23x08Info;
uint8_t deviceType, index;
uint8_t registers[];
uint8_t reg;
bool flag;

uint32_t led_time_check;
void led_toggling(void);

uint8_t dataOut[11];
uint8_t dataIn[3];
uint32_t led_time_check;
char x[10];

int main(void) {
    // initialize the device
    SYSTEM_Initialize();
    delay_ms(3000);

    mcp23x08_basic_initialize(MCP23008_TYPE, MCP23X08_PROTOCOL_I2C, MCP23X08_IIC_ADDRESS_A100, MCP23X08_SPI_ADDRESS_A00);
    mcp23x08_info(&mcp23x08Info);
    
#ifdef DEBUG_MODE

    mcp23x08_basic_get_type(&deviceType);
    if (deviceType == MCP23S08_TYPE)
        mcp23x08_interface_debug_print("Chip name :\t%s\n\r", mcp23x08Info.chip_name2);
    else
        mcp23x08_interface_debug_print("Chip name :\t%s\n\r", mcp23x08Info.chip_name1);
    mcp23x08_interface_debug_print("Manufacturer: \t%s\n\r", mcp23x08Info.manufacturer_name);
    if (deviceType == MCP23S08_TYPE)
        mcp23x08_interface_debug_print("Interface: \t%s\n\r", mcp23x08Info.interface2);
    else
        mcp23x08_interface_debug_print("Interface: \t%s\n\r", mcp23x08Info.interface1);
    mcp23x08_interface_debug_print("Supply voltage max : \t%0.2fV\n\r", mcp23x08Info.supply_voltage_max_v);
    mcp23x08_interface_debug_print("Supply voltage min: \t%0.2fV\n\r", mcp23x08Info.supply_voltage_min_v);
    mcp23x08_interface_debug_print("Maximum current: \t%0.1fmA\n\r", mcp23x08Info.max_current_ma);
    mcp23x08_interface_debug_print("Temperature Max: \t%.1fC\n\r", mcp23x08Info.temperature_max);
    mcp23x08_interface_debug_print("Temperature Min: \t%.1fC\n\r", mcp23x08Info.temperature_min);
    mcp23x08_interface_debug_print("Driver version: \tV%.1f\n\r", (mcp23x08Info.driver_version / 1000));

#endif
    /*initialize mcp23x08 pin mode*/
    mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_0, MCP23X08_OUTPUT);
    mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_1, MCP23X08_OUTPUT);
    mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_4, MCP23X08_INPUT);

    mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_6, MCP23X08_INPUT_PULLUP);
    mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_5, MCP23X08_INPUT_PULLUP);
    mcp23x08_basic_INT_enable(MCP23X08_GPIO_PIN_6, MCP23X08_INT_FALLING_EDGE);
    /*end of initialization*/
    
    mcp23x08_basic_read_register(MCP23X08_DIRECTION_REG, dataOut, 10);
	for(int index = 0; index < 11; index++){
		mcp23x08_interface_debug_print("Register default %d: 0x%.2x:", index, dataOut[index]);
		hex_to_bin(dataOut[index], x);
		mcp23x08_interface_debug_print(x);
		mcp23x08_interface_debug_print("\n\r");
	}

    while (1) {

                if (!mcp23x08_basic_gpio_read(MCP23X08_GPIO_PIN_5)) {
                    mcp23x08_interface_delay_ms(100);
                    if (!mcp23x08_basic_gpio_read(MCP23X08_GPIO_PIN_5))
                        mcp23x08_basic_gpio_toggle(MCP23X08_GPIO_PIN_0);
                }

        non_blocking_task(&led_toggling, _300_MS_TIMEOUT, led_time_check);

    }

    return 1;
}

void led_toggling(void) {

    user_led_Toggle();
    //    mcp23x08_basic_gpio_write(MCP23X08_GPIO_PIN_0, !mcp23x08_basic_gpio_read(MCP23X08_GPIO_PIN_0));
    //    mcp23x08_basic_gpio_write(MCP23X08_GPIO_PIN_1,MCP23X08_GPIO_HIGH);

    //    hex_to_bin(reg, registers);
    //    mcp23x08_interface_debug_print(registers);
    led_time_check = Tick_Count();

}

/*Known Issues
*external interrupt unstable
*/

/**
 End of File
 */

