#include <atmel_start.h>
#include <util/delay.h>
#include "utilies_file.h"
#include "mcp23x08_driver_basic.h"

/*function declaration*/
void led_toggling(void);

/*end of function declaration*/

mcp23x08_info_t mcp23x08Info;

uint8_t dataOut[];
uint8_t dataIn[3];
uint32_t led_time_check;
char x[10];
uint8_t y;

int main(void)
{
	/* Initializes MCU, drivers and middle-ware  */
	atmel_start_init();
	
	mcp23x08_basic_initialize(MCP23008_TYPE, MCP23X08_PROTOCOL_I2C, MCP23X08_IIC_ADDRESS_A110, MCP23X08_SPI_ADDRESS_A00);
	mcp23x08_info(&mcp23x08Info);

	mcp23x08_interface_debug_print("Chip name :\t%s\n\r", mcp23x08Info.chip_name1);
	mcp23x08_interface_debug_print("Manufacturer: \t%s\n\r", mcp23x08Info.manufacturer_name);

	mcp23x08_interface_debug_print("Interface: \t%s\n\r", mcp23x08Info.interface1);
	mcp23x08_interface_debug_print("Supply voltage max : \t%0.2fV\n\r", mcp23x08Info.supply_voltage_max_v);
	mcp23x08_interface_debug_print("Supply voltage min: \t%0.2fV\n\r", mcp23x08Info.supply_voltage_min_v);
	mcp23x08_interface_debug_print("Maximum current: \t%0.1fmA\n\r", mcp23x08Info.max_current_ma);
	mcp23x08_interface_debug_print("Temperature Max: \t%.1fC\n\r", mcp23x08Info.temperature_max);
	mcp23x08_interface_debug_print("Temperature Min: \t%.1fC\n\r", mcp23x08Info.temperature_min);
	mcp23x08_interface_debug_print("Driver version: \tV%.1f\n\r", (mcp23x08Info.driver_version / 1000));

	/* Replace with your application code */
	
	/*initialize mcp23x08 pin mode*/
	mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_0, MCP23X08_OUTPUT);  /**< define pin GP0 as an output */
	mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_1, MCP23X08_OUTPUT);  /**< define pin GP1 as an output */
	//mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_4, MCP23X08_OUTPUT);  /**< define pin GP4 as an output */

	mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_6, MCP23X08_INPUT_PULLUP);   /**< define pin GP6 as an input */
	mcp23x08_basic_gpio_set_mode(MCP23X08_GPIO_PIN_5, MCP23X08_INPUT_PULLUP);   /**< define pin GP5 as an input */
	mcp23x08_basic_INT_enable(MCP23X08_GPIO_PIN_6, MCP23X08_INT_FALLING_EDGE);  /**< enable pin GP6 interrupt in falling edge */
	/*end of initialization*/
	
	I2C_0_do_transfer( MCP23X08_DIRECTION_REG, dataOut, 10);
	//mcp23x08_basic_read_register(MCP23X08_DIRECTION_REG, dataOut, 1);
	for(int index = 0; index < 11; index++){
		mcp23x08_interface_debug_print("Register default %d: 0x%.2x :", index, dataOut[index]);
		hex_to_bin(dataOut[index], x);
		mcp23x08_interface_debug_print(x);
		mcp23x08_interface_debug_print("\n\r");
	}
		
	while (true) {
				
		led_toggle_non_blocking(&led_toggling, _1000_MS_TIMEOUT, led_time_check);

		if(!mcp23x08_basic_gpio_read(MCP23X08_GPIO_PIN_5))
		{
			mcp23x08_interface_delay_ms(100);
			if(!mcp23x08_basic_gpio_read(MCP23X08_GPIO_PIN_5))
			mcp23x08_basic_gpio_toggle(MCP23X08_GPIO_PIN_0);
			
		}

	}
}


void led_toggling(void) {

	user_led_toggle_level();
    mcp23x08_basic_gpio_toggle(MCP23X08_GPIO_PIN_1);
	led_time_check = Tick_Count();

}