/**
 * The MIT License (MIT)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sub-license, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * File:   mcp23x08_driver.h
 * Author: Cedric Akilimali
 *
 * Created on August 02, 2022, 3:13 PM
 */

#ifndef MCP23X08_DRIVER_H_INCLUDED
#define MCP23X08_DRIVER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdarg.h>

#define DEBUG_MODE

/**
 * @defgroup driver_mcp23x08 mcp23x08 driver function
 * @brief mcp23x08 driver modules
 * @{
 */

/**
 * @addtogroup mcp23x08_base_driver
 * @{
 */

/*Control Register */

#define MCP23X08_DIRECTION_REG                      0x00       /**< I/O Direction Register */
#define MCP23X08_INPUT_POLARITY_REG                 0x01       /**< Input Polarity port Register */
#define MCP23X08_INTERRUPT_ON_CHANGE_REG            0x02       /**< Interrupt on Change Pins register */
#define MCP23X08_DEFAULT_VALUE_REG                  0x03       /**< Default Value Register */
#define MCP23X08_INTERRUPT_ON_CHANGE_CONTROL_REG    0x04       /**< Interrupt on Change control register */
#define MCP23X08_EXPANDER_CONFIGURATION_REG         0x05       /**< I/O Expander Configuration Register */
#define MCP23X08_GPIO_PULLUP_REG                    0x06       /**< GPIO Pull-up Resistor register */
#define MCP23X08_INTERRUPT_FLAG_REG                 0x07       /**< Interrupt Flag Register */
#define MCP23X08_INTERRUPT_CAPTURED_REG             0x08       /**< Interrupt Captured Value for Port Register */
#define MCP23X08_GENERAL_PURPOSE_REG                0x09       /**< General Purpose I/O Port Register */
#define MCP23X08_OUTPUT_LATCH_REG                   0x0A       /**< Output Latch Register */

/*Register Mask */

#define MCP23X08_SEQOP_MASK                         0x20        /**< Sequential Operation Mode Mask */
#define MCP23X08_DISSLW_MASK                        0x10        /**< Slew Rate Control Bit for SDA Output Mask */
#define MCP23X08_HAEN_MASK                          0x08        /**< Hardware Address Enable mask */
#define MCP23X08_ODR_MASK                           0x04        /**< INT pin open-drain output Mask*/
#define MCP23X08_INTPOL_MASK                        0x02        /**< Interrupt polarity Mask */

/* GPIO Pin Mask */

#define MCP23x08_GP0_MASK                           0x01        /**< GPIO pin 0 Mask */
#define MCP23x08_GP1_MASK                           0x02        /**< GPIO pin 1 Mask */
#define MCP23x08_GP2_MASK                           0x04        /**< GPIO pin 2 Mask */
#define MCP23x08_GP3_MASK                           0x08        /**< GPIO pin 3 Mask */
#define MCP23x08_GP4_MASK                           0x10        /**< GPIO pin 4 Mask */
#define MCP23x08_GP5_MASK                           0x20        /**< GPIO pin 5 Mask */
#define MCP23x08_GP6_MASK                           0x40        /**< GPIO pin 6 Mask */
#define MCP23x08_GP7_MASK                           0x80        /**< GPIO pin 7 Mask */

#define MCP23x08_MAX_NUM_GPIO_PIN                   0x08

static uint8_t pinMask[MCP23x08_MAX_NUM_GPIO_PIN] = {	MCP23x08_GP0_MASK,
														MCP23x08_GP1_MASK,
														MCP23x08_GP2_MASK,
														MCP23x08_GP3_MASK,
														MCP23x08_GP4_MASK,
														MCP23x08_GP5_MASK,
														MCP23x08_GP6_MASK,
														MCP23x08_GP7_MASK};

/**
 * @brief mcp23x08 type enumeration
 */
typedef enum {
    MCP23008_TYPE = 0x00, /**< the msp23008 is the i2c version */
    MCP23S08_TYPE = 0x01  /**< the mcp23s08 is the spi version */
} mcp23x08_type_t;

/**
 * @brief mcp23x08 communication protocol enumeration
 */
typedef enum {
    MCP23X08_PROTOCOL_SPI = 0x00, /**< Communication protocol SPI */
    MCP23X08_PROTOCOL_I2C = 0x01  /**< Communication protocol I2C */
} mcp23x08_communication_protocol_t;

/**
 * @brief mcp23x08 i2c address enumeration
 */
typedef enum {
    MCP23X08_ADDRESS_DEFAULT  = 0x20, /**<  7bit Default slave Address */
    MCP23X08_IIC_ADDRESS_A000 = 0x00, /**<  A2A1A0 000 */
    MCP23X08_IIC_ADDRESS_A001 = 0x01, /**<  A2A1A0 001 */
    MCP23X08_IIC_ADDRESS_A010 = 0x02, /**<  A2A1A0 010 */
    MCP23X08_IIC_ADDRESS_A011 = 0x03, /**<  A2A1A0 011 */
    MCP23X08_IIC_ADDRESS_A100 = 0x04, /**<  A2A1A0 100 */
    MCP23X08_IIC_ADDRESS_A101 = 0x05, /**<  A2A1A0 101 */
    MCP23X08_IIC_ADDRESS_A110 = 0x06, /**<  A2A1A0 110 */
    MCP23X08_IIC_ADDRESS_A111 = 0x07  /**<  A2A1A0 111 */
} mcp23x08_iic_address_t;

/**
 * @brief mcp23x08 spi address enumeration
 */
typedef enum {
    MCP23X08_SPI_ADDRESS_A00 = 0x00, /**< A1A0 00 */
    MCP23X08_SPI_ADDRESS_A01 = 0x01, /**< A1A0 01 */
    MCP23X08_SPI_ADDRESS_A10 = 0x02, /**< A1A0 10 */
    MCP23X08_SPI_ADDRESS_A11 = 0x03  /**< A1A0 11 */
} mcp23x08_spi_address_t;

/**
 * @brief mcp23x08 boolean enumeration
 */
typedef enum {
    MCP23X08_BOOL_FALSE = 0x00, /**< Boolean state false */
    MCP23X08_BOOL_TRUE = 0x01   /**< Boolean state true */
} mcp23x08_bool_t;

/**
 * @brief mcp23x08 port mode enumeration
 */
typedef enum {
    MCP23X08_OUTPUT = 0x00, /**< Port configured as output mode */
    MCP23X08_INPUT  = 0x01, /**< Port configured as input mode */
    MCP23X08_INPUT_PULLUP = 0x10 /**< Port configured as input pull-up mode */
} mcp23x08_port_mode_t;

/**
 * @brief mcp23x08 gpio port enumeration
 */
typedef enum {
    MCP23X08_GPIO_PIN_0 = 0x00, /**< gpio port GP0 */
    MCP23X08_GPIO_PIN_1 = 0x01, /**< gpio port GP1 */
    MCP23X08_GPIO_PIN_2 = 0x02, /**< gpio port GP2 */
    MCP23X08_GPIO_PIN_3 = 0x03, /**< gpio port GP3 */
    MCP23X08_GPIO_PIN_4 = 0x04, /**< gpio port GP4 */
    MCP23X08_GPIO_PIN_5 = 0x05, /**< gpio port GP5 */
    MCP23X08_GPIO_PIN_6 = 0x06, /**< gpio port GP6 */
    MCP23X08_GPIO_PIN_7 = 0x07  /**< gpio port GP7 */
} mcp23x08_gpio_port_t;

/**
 * @brief mcp23x08 port polarity enumeration
 */
typedef enum {
    MCP23X08_POLARITY_SAME_LOGIC_STATE = 0x00, /**< GPIO register bit will reflect the same logic state of the input pin */
    MCP23X08_POLARITY_OPPOSITE_LOGIC_STATE = 0x01 /**< GPIO register bit will reflect the opposite logic state of the input pin */
} mcp23x08_port_polarity_t;

/**
 * @brief mcp23x08 interrupt flag enumeration
 */
typedef enum {
    MCP23X08_INT_CLEAR = 0x00, /**< Interrupt flag cleared */
    MCP23X08_INT_SET = 0x01    /**< Interrupt flag set */
} mcp23x08_int_flag_t;

/**
 * @brief mcp23x08 interrupt compare value enumeration
 */
typedef enum {
    MCP23X08_INT_COMP_TO_PREVIOUS_VALUE = 0x00, /**< Interrupt on change compares to value set on default register */
    MCP23X08_INT_COMP_TO_DEFAULT_VALUE = 0x01 /**< Interrupt on change compares to value previous port value */
} mcp23x08_int_compare_value_t;

/**
 * @brief mcp23x08 interrupt default value enumeration
 */
typedef enum {
    MCP23X08_INT_RISING_EDGE  = 0x00, /**< Interrupt on change default value to compare 0 */
    MCP23X08_INT_FALLING_EDGE = 0x01  /**< Interrupt on change default value to compare 1 */
} mcp23x08_int_default_value_t;

/**
 * @brief mcp23x08 interrupt open-drain enumeration
 */
typedef enum {
    MCP23X08_INT_ACTIVE_DRIVER = 0x00, /**< Active driver output (INTPOL bit sets the polarity) */
    MCP23X08_INT_OPEN_DRAIN_OUTPUT = 0x01 /**< Open-drain output (overrides the INTPOL bit) */
} mcp23x08_int_open_drain_mode_t;

/**
 * @brief mcp23x08 interrupt polarity enumeration
 */
typedef enum {
    MCP23X08_INT_ACTIVE_LOW = 0x00, /**< Interrupt active low */
    MCP23X08_INT_ACTIVE_HIGH = 0x01 /**< Interrupt active high */
} mcp23x08_int_polarity_t;

/**
 * @brief mcp23x08 interrupt captured value enumeration
 */
typedef enum {
    MCP23X08_INT_CAP_LOW = 0x00, /**< GPIO interrupt captured logic low */
    MCP23X08_INT_CAP_HIGH = 0x01 /**< GPIO interrupt captured logic high */
} mcp23x08_int_captured_state_t;

/**
 * @brief mcp23x08 logic level enumeration
 */
typedef enum {
    MCP23X08_GPIO_LOW = 0x00, /**< GPIO port logic level low */
    MCP23X08_GPIO_HIGH = 0x01 /**< GPIO port logic level high */
} mcp23x08_port_logic_level_t;

/**
 * @brief mcp23x08 handle structure definition
 */
typedef struct mcp23x08_handle_s {
    uint8_t(*i2c_init)(void);													/**< point to a iic init function address */
    uint8_t(*i2c_deinit)(void);													/**< point to a iic deinit function address */
    uint8_t(*i2c_write)(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len); /**< point to a i2c write function address */
    uint8_t(*i2c_read)(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len);	/**< point to a i2cread function address */
    uint8_t(*spi_init)(void);												    /**< point to a spi init function address */
    uint8_t(*spi_deinit)(void);													/**< point to a spi deinit function address */
    uint8_t(*spi_write)(uint8_t reg, uint8_t *buf, uint16_t len);				/**< point to a spi write function address */
    uint8_t(*spi_read)(uint8_t reg, uint8_t *buf, uint16_t len);				/**< point to a spi read function address */
    uint8_t(*gpio_write)(uint8_t state);										/**< point to gpio write for spi slave select and assert */
    void (*delay_ms)(uint32_t ms);												/**< point to a delay_ms function address */
    void(*debug_print)(char *fmt, ...);											/**< point to a debug_print function address */
    void (*receive_callback)(uint8_t type);										/**< point to a receive callback function address */
    uint8_t i2c_address;														/**< i2c device address */
    uint8_t spi_address;														/**< spi device address */
    uint8_t i2c_spi;															/**< i2c spi interface */
    uint8_t device_type;														/**< device type */
    uint8_t inited;																/**< inited flag */

} mcp23x08_handle_t;

/**
 * @brief mcp23x08 information structure definition
 */
typedef struct mcp23x08_info_s {
    char chip_name1[10];														/**< chip name 1 */
    char chip_name2[10];														/**< chip name 2*/
    char manufacturer_name[25];													/**< manufacturer name */
    char interface1[5];															/**< chip interface name */
    char interface2[5];															/**< chip interface name */
    float supply_voltage_min_v;													/**< chip min supply voltage */
    float supply_voltage_max_v;													/**< chip max supply voltage */
    float max_current_ma;														/**< chip max current */
    float temperature_min;														/**< chip min operating temperature */
    float temperature_max;														/**< chip max operating temperature */
    float driver_version;														/**< driver version */
} mcp23x08_info_t;

/**
 * @}
 */

/**
 * @defgroup mcp23x08_link_driver mcp23x08 link driver function
 * @brief    mcp23x08 link driver modules
 * @ingroup  mcp23x08 driver
 * @{
 */

/**
 * @brief     initialize pcf85xxx_handle_t structure
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] STRUCTURE is pcf85xxx_handle_t
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_INIT(HANDLE, STRUCTURE)           memset(HANDLE, 0, sizeof(STRUCTURE))

/**
 * @brief     link i2c_init function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a i2c_init function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_I2C_INIT(HANDLE, FUC)              (HANDLE)->i2c_init = FUC


/**
 * @brief     link i2c_deinit function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a i2c_deinit function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_I2C_DEINIT(HANDLE, FUC)            (HANDLE)->i2c_deinit = FUC


/**
 * @brief     link i2c_write function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a i2c_write function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_I2C_WRITE(HANDLE, FUC)             (HANDLE)->i2c_write = FUC


/**
 * @brief     link i2c_read function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a i2c_read function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_I2C_READ(HANDLE, FUC)              (HANDLE)->i2c_read = FUC

/**
 * @brief     link spi_init function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a spi_init function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_SPI_INIT(HANDLE, FUC)              (HANDLE)->spi_init = FUC

/**
 * @brief     link spi_deinit function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a spi_deinit function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_SPI_DEINIT(HANDLE, FUC)            (HANDLE)->spi_deinit = FUC

/**
 * @brief     link spi_write function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a spi_write function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_SPI_WRITE(HANDLE, FUC)             (HANDLE)->spi_write = FUC


/**
 * @brief     link spi_read function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a spi_read function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_SPI_READ(HANDLE, FUC)              (HANDLE)->spi_read = FUC

/**
 * @brief     link gpio write function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a gpio_write function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_GPIO_WRITE(HANDLE, FUC)            (HANDLE)->gpio_write = FUC

/**
 * @brief     link delay_ms function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a delay_ms function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_DELAY_MS(HANDLE, FUC)             (HANDLE)->delay_ms = FUC

/**
 * @brief     link debug_print function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a debug_print function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_DEBUG_PRINT(HANDLE, FUC)          (HANDLE)->debug_print = FUC

/**
 * @brief     link receive_callback function
 * @param[in] HANDLE points to mcp23x08 handle structure
 * @param[in] FUC points to a receive_callback function address
 * @note      none
 */
#define DRIVER_MCP23X08_LINK_RECEIVE_CALLBACK(HANDLE, FUC)     (HANDLE)->receive_callback = FUC


/**
 * @}
 */

/**
 * @defgroup mcp23x08_base_driver mcp23x08 base driver function
 * @brief    mcp23x08 base driver modules
 * @ingroup  mcp23x08_driver
 * @{
 */

/**
 * @brief      get chip's information
 * @param[out] *info points to mcp23x08 info structure
 * @return     status code
 *             - 0 success
 *             - 2 handle is NULL
 * @note       none
 */
uint8_t mcp23x08_info(mcp23x08_info_t *info);

/**
 * @brief     initialize the chip
 * @param[in] *handle points to mcp23x08 handle structure
 * @return    status code
 *            - 0 success
 *            - 1 i2c initialization failed
 *            - 2 handle is NULL
 *            - 3 linked functions is NULL
 * @note      none
 */
uint8_t mcp23x08_init(mcp23x08_handle_t *handle);

/**
 * @brief     close the chip
 * @param[in] *handle points to mcp23x08 handle structure
 * @return    status code
 *            - 0 success
 *            - 1 i2c deinit failed
 *            - 2 handle is NULL
 *            - 3 handle is not initialized
 * @note      none
 */
uint8_t mcp23x08_deinit(mcp23x08_handle_t *handle);

/**
 * @brief     irq handler
 * @param[in] *handle points to mcp23x08 handle structure
 * @return    status code
 *            - 0 success
 *            - 1 run failed
 *            - 2 handle is NULL
 *            - 3 handle is not initialized
 * @note      none
 */
uint8_t mcp23x08_irq_handler(mcp23x08_handle_t *handle);

/**
 * @brief     set the address pin
 * @param[in] *handle points to a mcp23x08 handle structure
 * @param[in] i2c_address is the chip i2c address pins
 * @param[in] spi_address is the chip spi address pins
 * @return    status code
 *            - 0 success
 *            - 2 handle is NULL
 * @note      none
 */
uint8_t mcp23x08_set_addr_pin(mcp23x08_handle_t *handle, mcp23x08_iic_address_t i2c_address, mcp23x08_spi_address_t spi_address);

/**
 * @brief     get the address pin
 * @param[in] *handle points to a mcp23x08 handle structure
 * @param[in] *addr_pin point to the chip address pins
 * @return    status code
 *            - 0 success
 *            - 2 handle is NULL
 * @note      none
 */
uint8_t mcp23x08_get_addr_pin(mcp23x08_handle_t *handle, mcp23x08_iic_address_t *addr_pin);

/**
 * @brief     set the chip type
 * @param[in] *handle points to mcp23x08 handle structure
 * @param[in] type is the chip type
 * @return    status code
 *            - 0 success
 *            - 2 handle is NULL
 * @note      none
 */
uint8_t mcp23x08_set_type(mcp23x08_handle_t *handle, mcp23x08_type_t type);

/**
 * @brief     get the chip type
 * @param[in] *handle points to mcp23x08 handle structure
 * @param[in] *type point to the chip type
 * @return    status code
 *            - 0 success
 *            - 2 handle is NULL
 * @note      none
 */
uint8_t mcp23x08_get_type(mcp23x08_handle_t *handle, mcp23x08_type_t *type);

/**
 * @brief     set communication protocol type
 * @param[in] *handle points to mcp23x08 handle structure
 * @param[in] protocol is I2c or spi serial protocol to communicate with the device
 * @return    status code
 *            - 0 success
 *            - 2 handle is NULL
 * @note      none
 */
uint8_t mcp23x08_set_comms_protocol(mcp23x08_handle_t *handle, mcp23x08_communication_protocol_t protocol);

/**
 * @brief     get communication protocol type
 * @param[in] *handle points to mcp23x08 handle structure
 * @param[in] *protocol point to the I2c or spi serial protocol set to communicate with the device
 * @return    status code
 *            - 0 success
 *            - 2 handle is NULL
 * @note      none
 */
uint8_t mcp23x08_get_comms_protocol(mcp23x08_handle_t *handle, mcp23x08_communication_protocol_t *protocol);

/**
 * @brief set pin mode (input, output or input_pullup)
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configure
 * @param[in] mode is the mode gpio port to set
 * @return status code
 *          - 0 success
 *          - 1 failed to set pin mode
 * @note   none
 */
uint8_t mcp23x08_set_pin_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_port_mode_t mode);

/**
 * @brief get pin mode (input, output or input_pullup)
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configure
 * @param[out] *mode point to the gpio port mode set
 * @return status code
 *          - 0 success
 *          - 1 failed to get pin mode
 * @note   none
 */
uint8_t mcp23x08_get_pin_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_port_mode_t *mode);

/**
 * @brief Write logic value to gpio pin
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to write (GP0 - GP7)
 * @param[in] logic_level is the logic level to assign to the pin
 * @return status code
 *          - 0 success
 *          - 1 failed to write pin
 * @note    none
 */
uint8_t mcp23x08_pin_write(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_port_logic_level_t logic_level);

/**
 * @brief Read logic level of gpio pin
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to read (GP0 - GP7)
 * @param[out] *logic_level point to the logic level assigned to the pin
 * @return status code
 *          - 0 success
 *          - 1 failed read pin
 * @note    none
 */
uint8_t mcp23x08_pin_read(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_port_logic_level_t *logic_level);


/**
 * @brief set pin pull-up mode
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to enable or disable pullup mode
 * @param[in] enable is the boolean logic to set
 * @return status code
 *          - 0 success
 *          - 1 failed failed to set pull-up mode
 * @note    none
 */
uint8_t mcp23x08_set_pin_pullup_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_bool_t enable);

/**
 * @brief get pin pull-up mode
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to enable or disable pullup mode
 * @param[out] *enable point to the boolean logic level
 * @return status code
 *          - 0 success
 *          - 1 failed get pull-up mode
 * @note    none
 */
uint8_t mcp23x08_get_pin_pullup_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_bool_t *enable);

/**
 * @brief set pin input polarity mode
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] polarity is the polarity value to assign
 * @return status code
 *          - 0 success
 *          - 1 failed to set polarity
 * @note    none
 */
uint8_t mcp23x08_set_pin_input_polarity_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_port_polarity_t polarity);

/**
 * @brief get pin input polarity mode
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[out] *polarity point to the polarity value to assigned to the pin
 * @return status code
 *          - 0 success
 *          - 1 failed to get polarity
 * @note    none
 */
uint8_t mcp23x08_get_pin_input_polarity_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_port_polarity_t *polarity);


/**
 * @brief set pin interrupt on change
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] enable is the boolean logic value to set
 * @return status code
 *          - 0 success
 *          - 1 failed failed to set interrupt
 * @note    none
 */
uint8_t mcp23x08_set_pin_interrupt(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_bool_t enable);

/**
 * @brief get pin interrupt on change
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[out] *enable point to the boolean logic value set
 * @return status code
 *          - 0 success
 *          - 1 failed to get interrupt status
 * @note    none
 */
uint8_t mcp23x08_get_pin_interrupt(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_bool_t *enable);

/**
 * @brief get pin interrupt flag
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[out] *flag point to interrupt flag status
 * @return status code
 *          - 0 success
 *          - 1 failed to get interrupt flag status
 * @note    none
 */
uint8_t mcp23x08_get_interrupt_flag(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_int_flag_t *flag);

/**
 * @brief clear pin interrupt flag
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] flag is the interrupt flag
 * @return status code
 *          - 0 success
 *          - 1 failed to get interrupt flag status
 * @note    none
 */
uint8_t mcp23x08_clear_interrupt_flag(mcp23x08_handle_t *handle/*, mcp23x08_gpio_port_t pin, mcp23x08_int_flag_t flag*/);

/**
 * @brief set interrupt output pin level when an interrutp occure
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] polarity is the interrupt pin level
 * @return status code
 *          - 0 success
 *          - 1 failed to set interrupt logic output logic level
 * @note    none
 */
uint8_t mcp23x08_set_intrrupt_pin_output_level(mcp23x08_handle_t *handle, mcp23x08_int_polarity_t logic_level);

/**
 * @brief get interrupt output pinlevel assigned when an interrutp occure
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[out] *polarity is the interrupt pin level
 * @return status code
 *          - 0 success
 *          - 1 failed to get interrupt logic output logic level
 * @note    none
 */
uint8_t mcp23x08_get_interrupt_pin_output_level(mcp23x08_handle_t *handle, mcp23x08_int_polarity_t *polarity);

/**
 * @brief set gpio pin polarity level when interrupt occure (
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] logic_level is the polarity level that will reflect on the pin when there is an interrupt
 * @return status code
 *          - 0 success
 *          - 1 failed set pin polarity level
 * @note    none
 */
uint8_t mcp23x08_set_pin_interrupt_caputure_level(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_int_captured_state_t logic_level);

/**
 * @brief get gpio pin polarity level when interrupt occure
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] *logic_level poin to the polarity level that reflect on the pin when there is an interrupt
 * @return status code
 *          - 0 success
 *          - 1 failed set pin polarity level
 * @note    none
 */
uint8_t mcp23x08_get_pin_interrupt_caputure_level(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_int_captured_state_t *logic_level);

/**
 * @brief set interrupt pin output mode (open drain or active mode)
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] mode is the outout mode
 * @return status code
 *          - 0 success
 *          - 1 failed set interrupt putput mode
 * @note    none
 */
uint8_t mcp23x08_set_interrupt_pin_output_mode(mcp23x08_handle_t *handle, mcp23x08_int_open_drain_mode_t mode);

/**
 * @brief Get interrupt pin output mode (open drain or not)
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[out] *mode is the outout mode
 * @return status code
 *          - 0 success
 *          - 1 failed get interrupt putput mode
 * @note    none
 */
uint8_t mcp23x08_get_interrupt_pin_output_mode(mcp23x08_handle_t *handle, mcp23x08_int_open_drain_mode_t *mode);

/**
 * @brief set the mode on how the associated pin value is compared for the interrupt-on-change
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] mode is the compare value mode
 * @return status code
 *          - 0 success
 *          - 1 failed set interrupt compare mode
 * @note    none
 */
uint8_t mcp23x08_set_ineterrupt_compare_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_int_compare_value_t mode);

/**
 * @brief get the mode on how the associated pin value is compared for the interrupt-on-change
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] *mode point the compare value mode
 * @return status code
 *          - 0 success
 *          - 1 failed set interrupt compare mode
 * @note    none
 */
uint8_t mcp23x08_get_ineterrupt_compare_mode(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_int_compare_value_t *mode);

/**
 * @brief set the compare value for pins configured for interrupt-on-change
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] value is the logic level
 * @return status code
 *          - 0 success
 *          - 1 failed to set interrupt default value
 * @note    none
 */
uint8_t mcp23x08_set_default_compare_value(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_int_default_value_t value);

/**
 * @brief get the compare value for pins configured for interrupt-on-change
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] pin is the gpio pin to configurer
 * @param[in] *value is the logic level
 * @return status code
 *          - 0 success
 *          - 1 failed to get interrupt default value
 * @note    none
 */
uint8_t mcp23x08_get_default_compare_value(mcp23x08_handle_t *handle, mcp23x08_gpio_port_t pin, mcp23x08_int_default_value_t *value);

/**
 * @brief set Hardware Address Enable for MCP23S08 only
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] enable is the boolean logic level
 * @return status code
 *          - 0 success
 *          - 1 failed set harware enable address status
 * @note    none
 */
uint8_t mcp23x08_set_hardware_address(mcp23x08_handle_t *handle, mcp23x08_bool_t enable);

/**
 * @brief get Hardware Address Enable for MCP23S08 only
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[out] *enable point to the boolean logic level
 * @return status code
 *          - 0 success
 *          - 1 failed get harware enable address status
 * @note    none
 */
uint8_t mcp23x08_get_hardware_address(mcp23x08_handle_t *handle, mcp23x08_bool_t *enable);

/**
 * @brief set Slew Rate Control Bit for SDA Output
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] enable is the boolean logic level to set
 * @return status code
 *          - 0 success
 *          - 1 failed set slew rate
 * @note    none
 */
uint8_t mcp23x08_set_slew_rate(mcp23x08_handle_t *handle, mcp23x08_bool_t enable);

/**
 * @brief get Slew Rate Control Bit for SDA Output
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] *enable point to the the boolean logic level set
 * @return status code
 *          - 0 success
 *          - 1 failed get slew rate
 * @note    none
 */
uint8_t mcp23x08_get_slew_rate(mcp23x08_handle_t *handle, mcp23x08_bool_t *enable);

/**
 * @brief set Sequential Operation Mode
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] enable is the boolean logic level to set
 * @return status code
 *          - 0 success
 *          - 1 failed set sequancial operation mode
 * @note    none
 */
uint8_t mcp23x08_set_sequencial_mode(mcp23x08_handle_t *handle, mcp23x08_bool_t enable);

/**
 * @brief get Sequential Operation Mode
 * @param[in] *handle point to mcp23x08 handle structure
 * @param[in] *enable point to the boolean logic level set
 * @return status code
 *          - 0 success
 *          - 1 failed get sequancial operation mode
 * @note    none
 */
uint8_t mcp23x08_get_sequencial_mode(mcp23x08_handle_t *handle, mcp23x08_bool_t *enable);

/**
 * @brief     set the chip register
 * @param[in] *handle points to mcp23x08 handle structure
 * @param[in] reg is the i2c register address
 * @param[in] *buf points to a data buffer
 * @param[in] length is the data buffer length
 * @return    status code
 *            - 0 success
 *            - 1 write failed
 *            - 2 handle is NULL
 *            - 3 handle is not initialized
 * @note      none
 */

uint8_t mcp23x08_set_reg(mcp23x08_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t length);

/**
 * @brief      get the chip register
 * @param[in]  *handle points to mcp23x08 handle structure
 * @param[in]  reg is the i2c register address
 * @param[out] *buf points to a data buffer
 * @param[in]  length is the data buffer length
 * @return     status code
 *             - 0 success
 *             - 1 read failed
 *             - 2 handle is NULL
 *             - 3 handle is not initialized
 * @note       none
 */
uint8_t mcp23x08_get_reg(mcp23x08_handle_t *handle, uint8_t reg, uint8_t *buf, uint16_t length);

/**
 * @}
 */

/**
 * @}
 */

#endif /**< MCP23X08_DRIVER_H_INCLUDED*/
