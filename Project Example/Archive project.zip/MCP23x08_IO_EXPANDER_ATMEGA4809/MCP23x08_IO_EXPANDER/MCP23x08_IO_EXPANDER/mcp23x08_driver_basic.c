/**
 * The MIT License (MIT)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * File:   mcp23x08_driver_basic.c
 * Author: Cedric Akilimali
 *
 * Created on August 04, 2022, 1:25 PM
 */

#include "mcp23x08_driver_basic.h"

/**
 * @brief basic example initialize
 * @param[in] device_type is the device type
 * @param[in] comms_protocol is the communication protocol
 * @param[in] i2c_Addr is the i2c slave user-defined hardware address bits (A2,A1,A0)
 * @param[in] spi_addr is the spi slave user-defined hardware address bits (A1,A0)
 * @return status code
 *          - 0 success
 *          - 1 initialize failed
 * @note    none
 */

uint8_t mcp23x08_basic_initialize(mcp23x08_type_t device_type, mcp23x08_communication_protocol_t comms_protocol, mcp23x08_iic_address_t i2c_Addr, mcp23x08_spi_address_t spi_addr) {
    volatile uint8_t res;
    volatile uint8_t index;

    /*link function*/
    DRIVER_MCP23X08_LINK_INIT(&mcp23x08_handle, mcp23x08_handle_t);
    DRIVER_MCP23X08_LINK_I2C_INIT(&mcp23x08_handle, mcp23008_interface_i2c_init);
    DRIVER_MCP23X08_LINK_I2C_DEINIT(&mcp23x08_handle, mcp23008_interface_i2c_deinit);
    DRIVER_MCP23X08_LINK_I2C_READ(&mcp23x08_handle, mcp23008_interface_i2c_read);
    DRIVER_MCP23X08_LINK_I2C_WRITE(&mcp23x08_handle, mcp23008_interface_i2c_write);
    DRIVER_MCP23X08_LINK_SPI_INIT(&mcp23x08_handle, mcp23s08_interface_spi_init);
    DRIVER_MCP23X08_LINK_SPI_DEINIT(&mcp23x08_handle, mcp23s08_interface_spi_deinit);
    DRIVER_MCP23X08_LINK_SPI_READ(&mcp23x08_handle, mcp23s08_interface_spi_read);
    DRIVER_MCP23X08_LINK_SPI_WRITE(&mcp23x08_handle, mcp23s08_interface_spi_write);
    DRIVER_MCP23X08_LINK_GPIO_WRITE(&mcp23x08_handle, mcp23x08_interface_gpio_write);
    DRIVER_MCP23X08_LINK_DELAY_MS(&mcp23x08_handle, mcp23x08_interface_delay_ms);
    DRIVER_MCP23X08_LINK_DEBUG_PRINT(&mcp23x08_handle, mcp23x08_interface_debug_print);
    DRIVER_MCP23X08_LINK_RECEIVE_CALLBACK(&mcp23x08_handle, mcp23x08_interface_receive_callback);


    /*mcp23x08 initialize*/
    res = mcp23x08_init(&mcp23x08_handle);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to initialize\n\r");
#endif
        return 1;
    }

    /*set device type*/
    res = mcp23x08_set_type(&mcp23x08_handle, device_type);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to set type\n\r");
#endif
        return 1;
    }

    /*set communication protocol*/
    res = mcp23x08_set_comms_protocol(&mcp23x08_handle, comms_protocol);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to set communication protocol\n\r");
#endif
        return 1;
    }

    /*set address pin*/
    res = mcp23x08_set_addr_pin(&mcp23x08_handle, i2c_Addr, spi_addr);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to set address pin\n\r");
#endif
        return 1;
    }

    /*set interrupt pin logic level*/
    res = mcp23x08_set_intrrupt_pin_output_level(&mcp23x08_handle, MCP23X08_INT_ACTIVE_LOW);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to set INT logic level\n\r");
#endif
        return 1;
    }

    /*set interrupt pin mode*/
    res = mcp23x08_set_interrupt_pin_output_mode(&mcp23x08_handle, MCP23X08_INT_OPEN_DRAIN_OUTPUT);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to INT output mode\n\r");
#endif
        return 1;
    }

    /*disable mcp23s08 spi hardware address mode by default */
    res = mcp23x08_set_hardware_address(&mcp23x08_handle, MCP23X08_BOOL_FALSE);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to disable hardware address mode\n\r");
#endif
        return 1;
    }

    /*disable i2c slewrate by default*/
    res = mcp23x08_set_slew_rate(&mcp23x08_handle, MCP23X08_BOOL_FALSE);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to disable slew rate\n\r");
#endif
        return 1;
    }

    /* disable sequencial mode*/
    res = mcp23x08_set_sequencial_mode(&mcp23x08_handle, MCP23X08_BOOL_TRUE);
    if (res) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to disable sequencial mode\n\r");
#endif
        return 1;
    }

    /*set interrupt compare mode*/
    for (index = 0; index < MCP23x08_MAX_NUM_GPIO_PIN; index++) {
        res = mcp23x08_set_ineterrupt_compare_mode(&mcp23x08_handle, index, MCP23X08_INT_COMP_TO_DEFAULT_VALUE);
        if (res) {
#ifdef DEBUG_MODE
            mcp23x08_interface_debug_print("mcp23x08: failed to set GP%d compare mode\n\r", index);
#endif
            return 1;
        }
    }

    /*set interrupt capture polarity */
    /*for (index = 0; index < MCP23x08_MAX_NUM_GPIO_PIN; index++) {
        res = mcp23x08_set_pin_interrupt_caputure_level(&mcp23x08_handle, index, MCP23X08_INT_CAP_LOW);
        if (res) {
#ifdef DEBUG_MODE
            mcp23x08_interface_debug_print("mcp23x08: failed to set GP%d capture polarity\n\r", index);
#endif
            return 1;
        }
    }*/

    /*set pin polarity mode*/
    for (index = 0; index < MCP23x08_MAX_NUM_GPIO_PIN; index++) {
        res = mcp23x08_set_pin_input_polarity_mode(&mcp23x08_handle, index, MCP23X08_POLARITY_SAME_LOGIC_STATE);
        if (res) {
#ifdef DEBUG_MODE
            mcp23x08_interface_debug_print("mcp23x08: failed to set GP%d input polarity\n\r", index);
#endif
            return 1;
        }
    }

    /*disable all pull-up*/
    for (index = 0; index < MCP23x08_MAX_NUM_GPIO_PIN; index++) {
        res = (mcp23x08_set_pin_pullup_mode(&mcp23x08_handle, index, MCP23X08_BOOL_FALSE) != 0);
        if (res) {
#ifdef DEBUG_MODE
            mcp23x08_interface_debug_print("mcp23x08: failed to disable GP%d pull-up\n\r", index);
#endif
            return 1;
        }
    }
    /*disable all interrupt*/
    for (index = 0; index < MCP23x08_MAX_NUM_GPIO_PIN; index++) {
        res = (mcp23x08_set_pin_interrupt(&mcp23x08_handle, index, MCP23X08_BOOL_FALSE) != 0);
        if (res) {
#ifdef DEBUG_MODE
            mcp23x08_interface_debug_print("mcp23x08: failed to disable GP%d interrupt\n\r", index);
#endif
            return 1;
        }
    }

    /*clear all interrupt flag*/
    for (index = 0; index < MCP23x08_MAX_NUM_GPIO_PIN; index++) {
        res = (mcp23x08_clear_interrupt_flag(&mcp23x08_handle/*, index, MCP23X08_BOOL_FALSE*/) != 0);
        if (res) {
#ifdef DEBUG_MODE
            mcp23x08_interface_debug_print("mcp23x08: failed to disable GP%d interrupt\n\r", index);
#endif
            return 1;
        }
    }

    /* wait 10 ms */
    mcp23x08_interface_delay_ms(10);

    return 0; /**< Initialize success */
}

/**
 * @brief interrupt request handle callback function
 * @param[in] *irq_callback point to the callback function
 * @return status code
 *          - 0 success
 *          - 1 fail to run handler
 */
uint8_t mcp23x08_basic_irq_handler(void) {
    if (mcp23x08_irq_handler(&mcp23x08_handle) != 0) {
        //mcp23x08_interface_debug_print("no interrupt\n\r");
        return 1; /**< failed to execute irq */
    }
    return 0; /**< success */
}

/**
 * @brief callback function to run interrupt service routine
 * @param[in] *irq_callback point to the interrupt routine function
 * @return status code
 *          - 0 succeed
 *          - 1 failed to run
 * @note none
 */
uint8_t mcp23x08_basic_gpio_irq_callBack(uint8_t(*irq_callback)(void)) {
    if ((*irq_callback)() != 0) {
        return 1;
    }
    return 0;

}

/**
 * @brief basic example to set gpio pin mode
 * @param[in] GPx is the gpio port to set mode
 * @param[in] mode is the desire mode to set the pin(input, output or input pull-up)
 * @return status code
 *          - 0 success
 *          - 1 failed
 * @note    none
 */
uint8_t mcp23x08_basic_gpio_set_mode(mcp23x08_gpio_port_t GPx, mcp23x08_port_mode_t mode) {
    uint8_t index;

    if (mode == MCP23X08_INPUT_PULLUP) {
        if (mcp23x08_set_pin_pullup_mode(&mcp23x08_handle, GPx, MCP23X08_BOOL_TRUE) != 0) {
            return 1; /**< failed to execute routine */
        }

        if (mcp23x08_set_pin_mode(&mcp23x08_handle, GPx, MCP23X08_INPUT) != 0) {
            return 1; /**< failed to execute routine */
        }
    } else {
        if (mcp23x08_set_pin_mode(&mcp23x08_handle, GPx, mode) != 0) {
            return 1; /**< failed to execute routine */
        }
        for (index = 0; index < MCP23x08_MAX_NUM_GPIO_PIN; index++) /**< clear port after setting the mode */
            mcp23x08_basic_gpio_write(index, MCP23X08_GPIO_LOW);
    }

    mcp23x08_interface_delay_ms(50);
    return 0; /**< success */
}

/**
 * @brief basic example to write logic value to gpio port
 * @param[in] GPx is the gpio port to write
 * @param[in] level is the logic level to write (HIGH or LOW)
 * @return status code
 *          - 0 success
 *          - 1 failed
 * @note    none
 */
uint8_t mcp23x08_basic_gpio_write(mcp23x08_gpio_port_t GPx, mcp23x08_port_logic_level_t level) {
    if (mcp23x08_pin_write(&mcp23x08_handle, GPx, level) != 0) {
        return 1; /**< failed to execute routine */
    }
    return 0; /**< success */
}

/**
 * @brief basic example to read gpio port
 * @param[in] GPx is the gpio port to read
 * @return GPIO read status
 * @note    none
 */
uint8_t mcp23x08_basic_gpio_read(mcp23x08_gpio_port_t GPx) {
    volatile uint8_t status;
    if (mcp23x08_pin_read(&mcp23x08_handle, GPx, (uint8_t *) &status) != 0) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to read pin%d\n\r", GPx); /**< failed to execute routine */
#endif
    }
    return status; /**< success */
}

/**
 * @brief basic example of gpio toggle function
 * @param[in] GPx is the port to toggle
 * @return status code
 *          - 0 success
 *          - 1 failed to toggle
 * @note    none
 */
uint8_t mcp23x08_basic_gpio_toggle(mcp23x08_gpio_port_t GPx) {
    if (mcp23x08_basic_gpio_write(GPx, !mcp23x08_basic_gpio_read(GPx)) != 0) {
        return 1; /**< failed to execute routine */
    }
    return 0;
    /**< success */;
}

/**
 * @brief basic example to enable interrupt
 * @param[in] GPx is the gpio port to enable interrupt
 * @param[in] edge_select is the Interrupt Edge Select bit (rising, or falling)
 * @return status code
 *          - 0 success
 *          - 1 failed
 * @note    none
 */
uint8_t mcp23x08_basic_INT_enable(mcp23x08_gpio_port_t GPx, mcp23x08_int_default_value_t edge_select) {
    if (mcp23x08_set_pin_interrupt(&mcp23x08_handle, GPx, MCP23X08_BOOL_TRUE) != 0) {
        return 1; /**< failed to execute routine */
    }
    if (mcp23x08_set_default_compare_value(&mcp23x08_handle, GPx, edge_select) != 0) {
        return 1; /**< failed to execute routine */
    }

    return 0; /**< success */
}

/**
 * @brief basic example to disable interrupt
 * @param[in] GPx is the gpio port to disable interrupt
 * @return status code
 *          - 0 success
 *          - 1 failed
 * @note    none
 */
uint8_t mcp23x08_basic_INT_disable(mcp23x08_gpio_port_t GPx) {
    if (mcp23x08_set_pin_interrupt(&mcp23x08_handle, GPx, MCP23X08_BOOL_FALSE) != 0) {
        return 1; /**< failed to execute routine */
    }
    return 0; /**< success */

}

/**
 * @brief basic example to clear interrupt flag
 * @param[in] GPx is the gpio port to clear interrupt flag
 * @return status code
 *          - 0 success
 *          - 1 failed
 * @note    none
 */
uint8_t mcp23x08_basic_clr_INT_flag(void) {
    if (mcp23x08_clear_interrupt_flag(&mcp23x08_handle/*, GPx, MCP23X08_INT_CLEAR*/) != 0) {
        return 1; /**< failed to excute routine */
    }
    return 0; /**< success */
}

/**
 * @brief basic example to get interrupt flag status
 * @param[in] GPx is the gpio port to clear interrupt flag
 * @param[out] *flag_status point to the interrupt flag status
 * @return interrupt status flag
 * @note    none
 */
uint8_t mcp23x08_basic_get_INT_flag(mcp23x08_gpio_port_t GPx, uint8_t *flag_status) {

    if (mcp23x08_get_interrupt_flag(&mcp23x08_handle, GPx, (uint8_t *) flag_status) != 0) {
#ifdef DEBUG_MODE
        mcp23x08_interface_debug_print("mcp23x08: failed to get interrupt GP%d flag\n\r", GPx); /**< failed to execute routine */
#endif
        return 1;
    }
    return 0; /**< success */
}

/**
 * @brief basic example get device type
 * @param[out] type
 * @return
 */
uint8_t mcp23x08_basic_get_type(mcp23x08_type_t *type) {

    volatile uint8_t status;
    if (mcp23x08_get_type(&mcp23x08_handle, (uint8_t *) & status) != 0) {
        return 1;
    }
    *type = (mcp23x08_type_t) (status);
    return 0; /**< success */

}

/**
 * @brief basic example read register
 * @param[in] reg is the i2c register address
 * @param[out] *buf points to a data buffer read
 * @param[in] len is the data buffer length
 * @return status code
 *          - 0 success
 *          - 1 failed to read register
 */
uint8_t mcp23x08_basic_read_register(uint8_t reg, uint8_t *buf, uint16_t len) {
    if (mcp23x08_get_reg(&mcp23x08_handle, reg, buf, len) != 0) {
        return 1; /**< failed to execute routine */
    }
    return 0; /**< success */
}

/**
 * @brief basic example write register
 * @param[in] reg is the i2c register address
 * @param[in] *buf points to a data buffer to write
 * @param[in] len is the data buffer length
 * @return status code
 *          - 0 success
 *          - 1 failed to write register
 */
uint8_t mcp23x08_basic_write_register(uint8_t reg, uint8_t *buf, uint16_t len) {
    if (mcp23x08_set_reg(&mcp23x08_handle, reg, buf, len) != 0) {
        return 1; /**< failed to execute routine */
    }
    return 0; /**< success */
}
/*end*/
