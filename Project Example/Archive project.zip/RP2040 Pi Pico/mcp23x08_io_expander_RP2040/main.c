#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/time.h"
#include "hardware/i2c.h"
#include "hardware/gpio.h"
#include "mcp23x08_driver/src/mcp23x08_driver_basic.h"

// sht40x_info_t sht40xInfo;
// sht40x_data_t dataRead;

int err;                        
uint32_t UID;                        /**< will hold the sensor unique ID*/                   
uint8_t variant;                     /**< will hold the sensor variant (as an int) */
uint8_t deviceAdd;                   /**< holds the device address when read*/         
uint8_t NumberSamples = 10;          /**< number of samples to read */

uint8_t i2c_write(uint8_t addr, uint8_t reg, uint8_t *pBuf, uint16_t len);
uint8_t i2c_read(uint8_t addr, uint8_t reg, uint8_t *pBuf, uint16_t len);

int main()
{
    stdio_init_all();

    // This example will use I2C0 on the default SDA and SCL pins (4, 5 on a Pico)

    i2c_init(i2c_default, 100 * 1000);             /*< 100Khz Baudrate*/
    gpio_set_function(PICO_DEFAULT_I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(PICO_DEFAULT_I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(PICO_DEFAULT_I2C_SDA_PIN);
    gpio_pull_up(PICO_DEFAULT_I2C_SCL_PIN);

    while (1)
    {
    }

    return 0;
}

/**
 * @brief This function re-format the i2c write function to be implemented into the sht4x driver
 * 
 * @param addr is the device slave address 
 * @param reg is the register to write
 * @param pBuf point to data to write to the sensor
 * @param len is the number of byte to write
 * @return none 
 */
uint8_t i2c_write(uint8_t addr, uint8_t reg, uint8_t *pBuf, uint16_t len)
{
 i2c_write_blocking(i2c_default, addr, (uint8_t*)&reg, 1, false);
}

/**
 * @brief This function re-format the i2c read function to be implemented into the sht4x driver
 * 
 * @param addr is the device slave address 
 * @param reg is the register to read
 * @param pBuf point to data read from the sensor
 * @param len is the number of byte to read
 * @return none 
 */
uint8_t i2c_read(uint8_t addr, uint8_t reg, uint8_t *pBuf, uint16_t len)
{
    i2c_read_blocking(i2c_default, addr, (uint8_t *)pBuf, len, false);
}
